package herencia.ejemplos.polimorfismo;

import java.util.ArrayList;

public class Main {

	// ArrayList de objetos SeleccionFutbol. Idenpendientemente de la clase hija
	// a la que pertenezca el objeto
	public static ArrayList<SeleccionFutbol> integrantes = new ArrayList<SeleccionFutbol>();

	public static void main(String[] args) {
		

		SeleccionFutbol entrenador = new Entrenador(1, "Francisco", "Pekerman", 60, 28489);
		SeleccionFutbol futbolista = new Futbolista(2, "Rodrigo", "Rodriguez", 24, 6, "Delantero");
		SeleccionFutbol futbolista1 = new Futbolista(2, "Leonel ", "Messi", 32, 10, "Delantero");
		SeleccionFutbol futbolista2 = new Futbolista(2, "Pedro", "Rojas", 16, 20, "Volante");
		SeleccionFutbol masajista = new Masajista(3, "Pedro", "Perez", 41, "Fisioterapeuta", 18);

		integrantes.add(entrenador);
		integrantes.add(futbolista);
		integrantes.add(futbolista1);
		integrantes.add(futbolista2);
		integrantes.add(masajista);

		System.out.println("--- Metodos de SuperClase---");
		
		// CONCENTRACION
		System.out.println("Todos los integrantes comienzan una concentracion. (Todos ejecutan el mismo m�todo)");
		for (SeleccionFutbol integrante : integrantes) {
			System.out.print(integrante.getNombre() + " " + integrante.getApellidos() + " -> ");
			integrante.concentrarse();
		}

		// VIAJE
		System.out.println("nTodos los integrantes viajan para jugar un partido. (Todos ejecutan el mismo m�todo)");
		for (SeleccionFutbol integrante : integrantes) {
			System.out.print(integrante.getNombre() + " " + integrante.getApellidos() + " -> ");
			integrante.viajar();
		}

		System.out.println("--- Metodos con Polimorfismo---");
		
		// ENTRENAMIENTO
		System.out.println(
				"nEntrenamiento: Todos los integrantes tienen su funci�n en un entrenamiento (Especializaci�n)");
		for (SeleccionFutbol integrante : integrantes) {
			System.out.print(integrante.getNombre() + " " + integrante.getApellidos() + " -> ");
			integrante.entrenamiento();
		}

		// PARTIDO DE FUTBOL
		System.out
				.println("nPartido de F�tbol: Todos los integrantes tienen su funci�n en un partido (Especializaci�n)");
		for (SeleccionFutbol integrante : integrantes) {
			System.out.print(integrante.getNombre() + " " + integrante.getApellidos() + " -> ");
			integrante.partidoFutbol();
		}
		
		System.out.println("--- Metodos de Clase---");

		// PLANIFICAR ENTRENAMIENTO
		System.out.println(
				"nPlanificar Entrenamiento: Solo el entrenador tiene el m�todo para planificar un entrenamiento:");
		System.out.print(entrenador.getNombre() + " " + entrenador.getApellidos() + " -> ");
		((Entrenador) entrenador).planificarEntrenamiento();

		// ENTREVISTA
		System.out.println("nEntrevista: Solo el futbolista tiene el m�todo para dar una entrevista:");
		System.out.print(futbolista.getNombre() + " " + futbolista.getApellidos() + " -> ");
		((Futbolista) futbolista).entrevista();

		// MASAJE
		System.out.println("nMasaje: Solo el masajista tiene el m�todo para dar un masaje:");
		System.out.print(masajista.getNombre() + " " + masajista.getApellidos() + " -> ");
		((Masajista) masajista).darMasaje();

	}
}


