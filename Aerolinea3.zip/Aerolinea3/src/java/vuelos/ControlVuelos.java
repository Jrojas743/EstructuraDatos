/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package vuelos;

import java.util.ArrayList;

public class ControlVuelos {

        public Vuelos vuelos = new Vuelos();
        public Integer origen;
        public Integer destino;
        public String ruta;
        public Vuelos v = new Vuelos();
        public ArrayList listado = new ArrayList();
        public ArrayList list1 = new ArrayList();

        public ControlVuelos() {
        }

        public ControlVuelos(Integer org, Integer dest) {

                this.origen = org;
                this.destino = dest;

                vuelos.buscarRuta(origen, destino);
                this.ruta = String.valueOf(vuelos.idRuta.get(0));
                System.out.println("DEBUG: " + ruta);
        }

        public ArrayList getListado() {

                vuelos.buscarVuelos(ruta);
                listado = vuelos.getListado();
                return listado;

        }

        public String getValor(Integer vuelo) {
                return vuelos.buscarVuelo(vuelo);

        }

        public boolean descontarSilla(Integer vuelo) {

                return vuelos.descontarSilla(vuelo);
        }

        public Integer getNumeroVuelo(Integer id) {
                return v.obtenerNoVuelo(id);
        }

}
