/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package vuelos;

import java.sql.ResultSet;
import java.util.ArrayList;

import identificacion.DbConexion;

public class Vuelos {

    public ArrayList<String> idRuta = new ArrayList();
    public ArrayList<Integer> vuelosOrigen = new ArrayList();
    public ArrayList<Integer> vuelosDestino = new ArrayList();
    public ArrayList<Integer> idVuelos = new ArrayList();
    public ArrayList<String> rutas = new ArrayList();
    public ArrayList<String> horasalidas = new ArrayList();
    public ArrayList<String> horallegadas = new ArrayList();
    public ArrayList<String> tiposAvion = new ArrayList();
    public ArrayList<Integer> asientos = new ArrayList();

    public ArrayList listadoVuelos = new ArrayList();

    private ResultSet rs;
    private DbConexion db;

    public Vuelos() {
    }

    public Integer obtenerNoVuelo(Integer id) {
        int vueloNo = 0;
        try {
            db = new DbConexion();

            String sql = "select * from reserva where id_reserva='" + id + "'";
            rs = db.getQuery(sql);
            while (rs.next()) {

                vueloNo = rs.getInt("numeroVuelo");
            }

        } catch (Exception ex) {
            System.out.println("Error obteniendo No Vuelo");
            System.out.println(ex);

        }

        return vueloNo;

    }

    void buscarRuta(Integer org, Integer dest) {

        try {
            db = new DbConexion();
            String sql = "select * from rutas where origen = '" + org + "' and destino = '" + dest + "'";
            rs = db.getQuery(sql);

            while (rs.next()) {

                idRuta.add(rs.getString("id_rutas"));
                vuelosOrigen.add(rs.getInt("origen"));
                vuelosDestino.add(rs.getInt("destino"));

            }
            System.out.println("Ruta obtenida satisfactoriamente");

        } catch (Exception ex) {
            System.out.println("Error obeniendo Ruta");
            System.out.println(ex);

        }

    }

    String buscarVuelo(Integer vuelo) {
        String valor = null;
        try {
            db = new DbConexion();
            String sql = "select * from vuelos where id_vuelo = '" + vuelo + "'";
            rs = db.getQuery(sql);

            while (rs.next()) {
                valor = rs.getString("valor");
            }
            System.out.println("Vuelo seleccionado Satisfacioriamente");
            System.out.println("Valor vuelo: " + valor);

        }

        catch (Exception ex) {
            System.out.println("Error buscando vuelo");
            System.out.println(ex);

        }
        return valor;
    }

    void buscarVuelos(String ruta) {
        try {
            db = new DbConexion();
            String sql = "select * from vuelos where ruta = '" + ruta + "'";
            rs = db.getQuery(sql);

            while (rs.next()) {

                listadoVuelos.add(rs.getInt("id_vuelo"));
                listadoVuelos.add(rs.getString("ruta"));
                listadoVuelos.add(rs.getString("horasalida"));
                listadoVuelos.add(rs.getString("horallegada"));
                tiposAvion.add(rs.getString("tipoAvion"));
                listadoVuelos.add(rs.getString("tipoAvion"));
                listadoVuelos.add(rs.getInt("asientos"));
            }
            System.out.println("Vuelos obtenidos satisfactoriamente");
            imprimirVuelos();
        }

        catch (Exception ex) {
            System.out.println("Error obeniendo Vuelos");
            System.out.println(ex);

        }
    }

    public ArrayList getListado() {
        return this.listadoVuelos;
    }

    boolean descontarSilla(Integer vuelo) {
        int asiento = 0;
        try {
            db = new DbConexion();

            String sql = "select * from vuelos where id_vuelo='" + vuelo + "'";
            rs = db.getQuery(sql);
            while (rs.next()) {

                asiento = rs.getInt("asientos");
            }

            sql = "update vuelos set asientos='" + (asiento - 1) + "' where id_vuelo='" + vuelo + "'";

            int res = db.setUpdate(sql);
            if (res == 0) {
                System.out.println("UPDATE NO realizado");
                return false;
            } else
                System.out.println("Silla Descontada");

        } catch (Exception ex) {
            System.out.println("Error descontando silla");
            System.out.println(ex);
            return false;
        }
        return true;
    }

    private void imprimirVuelos() {
        for (int i = 0; i < idVuelos.size(); i++) {
            System.out.println("Debug: " + idVuelos.get(i));
        }
    }

}
