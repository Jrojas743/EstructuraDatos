/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package identificacion;

import java.sql.*;

public class DbConexion {

    private Connection con = null;
    private String driver = "com.mysql.jdbc.Driver";
    private String url = "jdbc:mysql://localhost:3306/miaerolinea";
    private String usr = "root";
    private String pwd = "root";

    public DbConexion() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        try {

            Class.forName(driver).newInstance();
            con = DriverManager.getConnection(url, usr, pwd);
        } catch (SQLException e) {

            System.out.println("Error en la conexion");

        }
    }

    public ResultSet getQuery(String sql) {
        ResultSet rs = null;

        try {
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
        } catch (SQLException se) {
            se.printStackTrace();
        }
        return rs;
    }

    public int setUpdate(String sql) {
        int nr = 0;
        try {
            Statement st = con.createStatement();
            nr = st.executeUpdate(sql);
        } catch (SQLException se) {
            se.printStackTrace();
        }
        return nr;

    }

}
