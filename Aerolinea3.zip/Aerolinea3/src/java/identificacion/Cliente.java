/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package identificacion;

import java.sql.ResultSet;

public class Cliente {

    private ResultSet rs;
    private DbConexion db;
    private String nameUsr = null;
    private String idUsr = null;
    private String permiso = null;
    public boolean login = false;

    public String verificar(String nombre, String password) {

        try {
            db = new DbConexion();
            rs = db.getQuery(
                    "Select * from cliente where nickname= '" + nombre + "' and password = '" + password + "'");

            while (rs.next()) {
                idUsr = rs.getString("id");
                nameUsr = rs.getString("nombre");
                permiso = rs.getString("permiso");
            }
            System.out.println("welcome " + nameUsr + " " + idUsr);
            login = true;
        } catch (Exception ex) {
            System.out.println("Error en statement");
            System.out.println(ex);
            login = false;
        }
        return nameUsr;

    }

    public String getId() {
        return idUsr;
    }

    public String getPermiso() {
        return permiso;
    }

}
