/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package identificacion;

public class ControlIngreso {

    public Cliente c = new Cliente();
    public String nombre;
    public String id;
    public String permiso;

    public ControlIngreso(String s, String p) {

        nombre = c.verificar(s, p);
        id = c.getId();
        permiso = c.getPermiso();
    }

    public String getNombre() {

        return nombre;
    }

    public String getId() {
        return id;
    }

    public String getPermiso() {
        return permiso;
    }

}
