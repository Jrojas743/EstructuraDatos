/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package reservas;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

import identificacion.DbConexion;

public class Reservas {

    public ArrayList listadoReservas = new ArrayList();
    public ArrayList<Integer> ids = new ArrayList();
    private Integer idReserva;
    private Integer idnext;
    private ResultSet rs;
    private DbConexion db;

    public Reservas() {
    }

    public ArrayList traerReservas(String idUsr) {
        int j = 0;
        try {
            db = new DbConexion();

            String sql = "select * from reserva where id_usr ='" + idUsr + "'";
            rs = db.getQuery(sql);
            while (rs.next()) {

                listadoReservas.add(rs.getInt("id_reserva"));
                ids.add(rs.getInt("id_reserva"));
                System.out.println("id Reserva: " + ids.get(j));
                j++;
                listadoReservas.add(rs.getInt("numeroVuelo"));
                listadoReservas.add(rs.getString("fecha_expedicion"));
                listadoReservas.add(rs.getString("fechaorigen"));
                listadoReservas.add(rs.getString("origen"));
                listadoReservas.add(rs.getString("fechadestino"));
                listadoReservas.add(rs.getString("destino"));
            }

        } catch (Exception ex) {
            System.out.println("Error realizando reserva");
            System.out.println(ex);

        }
        return listadoReservas;

    }

    public ArrayList traerReservasPagos(String idUsr) {
        int j = 0;
        try {
            db = new DbConexion();

            String sql = "select * from reserva where id_usr ='" + idUsr + "'";
            rs = db.getQuery(sql);
            while (rs.next()) {

                listadoReservas.add(rs.getInt("id_reserva"));
                ids.add(rs.getInt("id_reserva"));
                System.out.println("id Reserva pagos: " + ids.get(j));
                j++;
                listadoReservas.add(rs.getInt("numeroVuelo"));
                listadoReservas.add(rs.getString("fecha_expedicion"));

                listadoReservas.add(rs.getString("origen"));

                listadoReservas.add(rs.getString("destino"));
                listadoReservas.add(rs.getString("valor"));
            }
            return listadoReservas;

        } catch (Exception ex) {
            System.out.println("Error en traerReservasPagos Pagos");
            System.out.println(ex);

        }
        return listadoReservas;

    }

    public ArrayList traerReservasPagadas(String idUsr) {
        int j = 0;
        try {
            db = new DbConexion();

            String sql = "select * from reserva where id_usr ='" + idUsr + "'";
            rs = db.getQuery(sql);
            while (rs.next()) {

                if (rs.getInt("pago") == 1) {

                    listadoReservas.add(rs.getInt("id_reserva"));
                    ids.add(rs.getInt("id_reserva"));
                    System.out.println("id Reserva: " + ids.get(j));
                    j++;
                    listadoReservas.add(rs.getInt("numeroVuelo"));
                    listadoReservas.add(rs.getString("fecha_expedicion"));
                    listadoReservas.add(rs.getString("origen"));
                    listadoReservas.add(rs.getString("destino"));
                    listadoReservas.add(rs.getString("asiento"));
                } else {
                }
            }

        }

        catch (Exception ex) {
            System.out.println("Error realizando reserva");
            System.out.println(ex);

        }
        return listadoReservas;

    }

    public Integer reservarVuelo(String idUsr, String vuelo, String nombre, String fechao, String fechad, String origen,
            String destino) {
        try {
            db = new DbConexion();
            calcularId();
            Date d = new Date();
            String date = d.toString();
            System.out.println("Date:" + date);
            System.out.println("idnext: " + idnext);

            String sql = "insert into reserva(id_reserva,numeroVuelo,fecha_expedicion,id_usr,asiento,pago,valor,fechaorigen,fechadestino,origen,destino) values('"
                    + idnext + "','" + vuelo + "','" + date + "','" + idUsr + "','A1','0','0','" + fechao + "','"
                    + fechad + "','" + origen + "','" + destino + "')";
            int res = db.setUpdate(sql);
            if (res == 0) {
                System.out.println("Reserva NO realizada");
            } else
                System.out.println("Reserva realizada");

        } catch (Exception ex) {
            System.out.println("Error realizando reserva");
            System.out.println(ex);

        }

        return idReserva;

    }

    public void calcularId() {
        int id = 0;

        for (int i = 0; i < ids.size(); i++) {
            System.out.println("id: " + ids.get(i));

            if (ids.get(i) > id) {
                id = ids.get(i);
            }

        }

        idnext = id;

    }

    public Integer eliminarReserva(Integer id) {
        try {
            db = new DbConexion();

            String sql = "delete from reserva where id_reserva='" + id + "'";
            int res = db.setUpdate(sql);
            if (res == 0) {
                System.out.println("Delete NO realizado");
            } else
                System.out.println("Reserva eliminada");

        } catch (Exception ex) {
            System.out.println("Error realizando reserva");
            System.out.println(ex);

        }

        return idReserva;

    }

    public Integer registarPago(Integer id, String valor) {
        try {
            db = new DbConexion();
            int reserva = 0;
            String sql = "select * from reserva where id_reserva='" + id + "'";
            rs = db.getQuery(sql);
            while (rs.next()) {

                reserva = rs.getInt("id_reserva");
            }

            sql = "update reserva set valor='" + valor + "', pago='" + 1 + "' where id_reserva='" + reserva + "'";

            int res = db.setUpdate(sql);
            if (res == 0) {
                System.out.println("UPDATE NO realizado");
            } else
                System.out.println("Pago Registrado");

        } catch (Exception ex) {
            System.out.println("Error Pagando Reserva");
            System.out.println(ex);

        }

        return idReserva;

    }

    Integer reservarSilla(Integer id, String sillaNo) {

        try {
            db = new DbConexion();

            String sql = "update reserva set asiento='" + sillaNo + "' where id_reserva=" + id + "";
            int res = db.setUpdate(sql);
            if (res == 0) {
                System.out.println("Update no realizado");
            } else
                System.out.println("Echeking registrado");

        } catch (Exception ex) {
            System.out.println("Error realizando Echeking");
            System.out.println(ex);

        }

        return idReserva;

    }

}
