
package reservas;

import java.util.ArrayList;

public class ControlReservas {

    private String idUsuario;
    public ArrayList listadoReservas = new ArrayList();
    public ArrayList listadoReservasPagadas = new ArrayList();
    public ArrayList listadoReservasPagos = new ArrayList();
    private Reservas r = new Reservas();

    public ControlReservas() {
    }

    public ControlReservas(String idUsr, String vuelo, String nombre, String fechao, String fechad, String origen,
            String destino) {
        this.idUsuario = idUsr;
        r.reservarVuelo(idUsr, vuelo, nombre, fechao, fechad, origen, destino);

    }

    public void traerReservas(String idUsr) {

        listadoReservas = r.traerReservas(idUsr);

    }

    public void traerReservasPagadas(String idUsr) {

        listadoReservasPagadas = r.traerReservasPagadas(idUsr);

    }

    public void traerReservasPagos(String idUsr) {

        listadoReservasPagos = r.traerReservasPagos(idUsr);

    }

    public void reservarSilla(Integer id, String sillaNo) {
        r.reservarSilla(id, sillaNo);
    }

    public void eliminar(Integer id) {
        r.eliminarReserva(id);
    }

    public void registarPago(Integer id, String pago) {
        r.registarPago(id, pago);
    }

}
