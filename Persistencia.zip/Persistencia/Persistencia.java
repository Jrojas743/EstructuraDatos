/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package persistencia;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author jroja
 */
public class Persistencia {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        
        FileWriter fichero = new FileWriter ("C:/Users/jroja/OneDrive/Documentos/persistencia.txt");
        fichero.write("Juan Daniel Rojas"+ "\n");
        fichero.write("Ingenieria de Sistemas"+ "\n");
        fichero.write("U00131771"+ "\n");
        fichero.write("jrojas743@unab.edu.co"+ "\n");
        fichero.write("22"+ "\n");
        fichero.write("Estructura de Datos"+ "\n");
        fichero.write("3003222837"+ "\n");
        fichero.write("Cuarto"+ "\n");
        fichero.write("Floridablanca"+ "\n");
        fichero.write("Soltero");
        
        fichero.close();
    }
    
}
